f0(X,Y):-between(21,23,X),
       between(X,24,Y).
f0(25,25).

f1(X,Y):-!,
    between(21,23,X),
    between(X,24,Y).
f1(25,25).

f2(X,Y):-between(21,23,X),
    !,
    between(X,24,Y).
f2(25,25).

f3(X,Y):-between(21,23,X),
    between(X,24,Y),
    !.
f3(25,25).
